using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class SmoothOrbitFrame : OrbitFrame
{
	private Vector3 targetPosition;
	private float currentVelocity;
	
	public SmoothOrbitFrame(float targetAngleXZ, float targetAngleXY, float targetDistance, float startTime, Vector3 targetPosition, float duration, bool relative, GameEntity[] relativeEntities)
							 : base(targetAngleXZ, targetAngleXY, targetDistance, startTime, duration, relativeEntities, relative)
	{
		this.targetPosition = targetPosition;
	}
	
	public override Vector3 GetNextPosition(float elapsed)
	{
		if(targetPosition!=Vector3.zero )
		{
			if(targetEntities==null)
			{
				return targetPosition;
			}
			else
			{
				return targetPosition;
			}
		}

		float angleXZ = Mathf.Lerp(startAngleXZ, targetAngleXZ, elapsed/duration);
		float angleXY = Mathf.Lerp(startAngleXY, targetAngleXY, elapsed/duration);
		float distance = Mathf.Lerp(startDistance, targetDistance, elapsed/duration);

		return base.ComputeCameraPosition(angleXZ, angleXY, distance)+base.GetTargetBounds().center;
	}
};