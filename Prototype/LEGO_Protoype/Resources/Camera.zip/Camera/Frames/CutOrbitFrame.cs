using UnityEngine;
using System.Collections;

public class CutOrbitFrame : OrbitFrame
{

	public CutOrbitFrame(float targetAngleXZ, float targetAngleXY, float targetDistance, float startTime, float duration, bool relative,GameEntity[] relativeEntities)
							 : base(targetAngleXZ, targetAngleXY, targetDistance, startTime, duration, relativeEntities, relative)
	{
		
	}
	
	public override Vector3 GetNextPosition(float elapsed)
	{
		if(targetEntities!=null)
		{
			if(targetEntities.Length==1 && relative)
			{
				return targetEntities[0].GetGameObject().transform.localToWorldMatrix.MultiplyPoint3x4(ComputeCameraPosition(targetAngleXZ, targetAngleXY, targetDistance));	
			}
			else
			{
				return ComputeCameraPosition(targetAngleXZ, targetAngleXY, targetDistance)+GetTargetBounds().center;				
			}
			
		}
		return ComputeCameraPosition(targetAngleXZ, targetAngleXY, targetDistance);
	}
}

