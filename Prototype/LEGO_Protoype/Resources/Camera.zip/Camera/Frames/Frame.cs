using UnityEngine;
using System.Collections;

public abstract class Frame
{
	protected float startTime;
	protected float duration;
	protected GameEntity[] targetEntities;
	
	public Frame(float startTime, float duration, GameEntity[] targetEntities)
	{
		this.startTime = startTime;
		this.duration = duration;
		this.targetEntities = targetEntities;
	}
	
	public Bounds GetTargetBounds()
	{
		if(targetEntities!=null && targetEntities.Length>0)
		{
			Bounds targetLookBounds = targetEntities[0].GetRealBounds();
			
			if(targetEntities.Length>1)
			{
				for(int i=1; i<targetEntities.Length; ++i)
				{
					targetLookBounds.Encapsulate(targetEntities[i].GetRealBounds());
				}
			}
			return targetLookBounds;
		}
		return new Bounds(Vector3.zero, Vector3.zero);
	}
	
	public float GetStartTime()
	{
		return startTime;
	}
	
	public float GetDuration()
	{
		return duration;
	}
}

