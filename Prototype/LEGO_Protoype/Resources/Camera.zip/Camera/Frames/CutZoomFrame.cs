using UnityEngine;
using System.Collections;

public class CutZoomFrame : ZoomFrame
{
	public CutZoomFrame(float startTime, float targetFov, float frameDuration, GameEntity[] targetEntities) : base(startTime, targetFov, frameDuration, targetEntities) 
	{
	}
	
	public override float GetNextFov(float elapsed)
	{
		return targetFov;
	}
	
}

