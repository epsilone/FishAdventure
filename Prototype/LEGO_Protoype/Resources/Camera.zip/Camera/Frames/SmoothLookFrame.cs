using UnityEngine;
using System.Collections;

public class SmoothLookFrame : LookFrame
{
	private Transform startTransform;
	private Vector3 startPosition;
	private Vector3 endPosition;
	private bool relative;
	
	public SmoothLookFrame(float startTime, float duration, GameEntity[] targetEntities, Transform cameraTransform, Vector3 startPosition, 
						   Vector3 endPosition, bool relative) : base(startTime, duration, targetEntities, cameraTransform)
	{
		this.startPosition = startPosition;
		this.endPosition = endPosition;
		this.relative = relative;
	}
	
	public override Quaternion GetNextRotation(float elapsed)
	{
		Vector3 newStartPosition = Vector3.zero;
		Quaternion startRot = Quaternion.identity;
		Quaternion endRot = Quaternion.identity;
		//Vector3 newEndPosition;
		
		if(relative && targetEntities.Length>1)
		{
			Transform targetTransform = targetEntities[0].GetGameObject().transform;
			Vector3 heightVector = new Vector3(0, base.GetTargetBounds().extents.y, 0);
			newStartPosition = targetTransform.localToWorldMatrix.MultiplyPoint3x4(startPosition) + heightVector;
//			newEndPosition = targetTransform.localToWorldMatrix.MultiplyPoint3x4(endPosition) + heightVector;
		}
		
		else
		{
			startRot = Quaternion.LookRotation((base.GetTargetBounds().center + newStartPosition)-cameraTransform.position);
			endRot = Quaternion.LookRotation((base.GetTargetBounds().center + endPosition)-cameraTransform.position);
//			newStartPosition = base.GetTargetBounds().center + newStartPosition;
//			newEndPosition = base.GetTargetBounds().center + endPosition;
		}
//
		return Quaternion.Slerp(startRot, endRot, elapsed/duration);
//		return Quaternion.LookRotation((Vector3.Slerp(newStartPosition, newEndPosition, elapsed/duration)-cameraTransform.position).normalized);
	}
	
}

