using UnityEngine;
using System.Collections;

public abstract class LookFrame : Frame, ILook
{
	protected Transform cameraTransform;
	
	public LookFrame(float startTime, float duration, GameEntity[] targetEntities, Transform cameraTransform)
							 : base(startTime, duration, targetEntities)
	{
		this.cameraTransform = cameraTransform;
	}	
	
	public abstract Quaternion GetNextRotation(float elapsed);
	
	public void SetStartLookPosition(Vector3 startPos)
	{
	
	}
}

