using UnityEngine;
using System.Collections;

public class SmoothZoomFrame : ZoomFrame
{
	public SmoothZoomFrame(float startTime, float targetFov, float frameDuration, GameEntity[] targetEntities) : base(startTime, targetFov, frameDuration, targetEntities) 
	{
	}
	
	public override float GetNextFov(float elapsed)
	{
		return Mathf.Lerp(startFov, targetFov, elapsed/fovlerpDuration);
	}
}

