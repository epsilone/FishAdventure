using UnityEngine;
using System.Collections;

public abstract class OrbitFrame : Frame, IOrbit
{
	protected float targetAngleXZ;
	protected float targetAngleXY;
	protected float targetDistance;
	protected float startAngleXZ;
	protected float startAngleXY;
	protected float startDistance;
	protected bool relative = false;
	
	
	public OrbitFrame(float targetAngleXZ, float targetAngleXY, float targetDistance, float startTime, float duration, 
					 GameEntity[] relativeEntities, bool relative) : base(startTime, duration, relativeEntities)
	{
		this.targetAngleXZ = targetAngleXZ;
		this.targetAngleXY = targetAngleXY;
		this.targetDistance = targetDistance;
		this.relative = relative;
	}
	
	public abstract Vector3 GetNextPosition(float elapsed);
	
	public void SetStartAngleXZ(float startAngleXZ)
	{
		this.startAngleXZ = startAngleXZ;
	}
	
	public void SetStartAngleXY(float startAngleXY)
	{
		this.startAngleXY = startAngleXY;
	}
	
	public void SetStartDistance(float startDistance)
	{
		this.startDistance = startDistance;	
	}
	
	public Vector3 ComputeCameraPosition(float angleXZ, float angleXY, float distance)
	{
		Vector2 angleVector = new Vector2(Mathf.Cos(angleXY * Mathf.Deg2Rad)*distance, Mathf.Sin(angleXY * Mathf.Deg2Rad)*distance);
		return new Vector3(Mathf.Sin(angleXZ*Mathf.Deg2Rad)*angleVector.x, angleVector.y, Mathf.Cos(angleXZ*Mathf.Deg2Rad)*angleVector.x);	
	}
}