using UnityEngine;
using System.Collections;

public interface IOrbit 
{
	Vector3 GetNextPosition(float elapsed);
	void SetStartAngleXZ(float value);
	void SetStartAngleXY(float value);
	void SetStartDistance(float value);
}

