using UnityEngine;
using System.Collections;

public interface ILook
{
	Quaternion GetNextRotation(float elapsed);
	void SetStartLookPosition(Vector3 startPosition);
}

