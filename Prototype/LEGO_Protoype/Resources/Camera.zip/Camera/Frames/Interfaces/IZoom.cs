using UnityEngine;
using System.Collections;

public interface IZoom
{
	float GetNextFov(float elapsed);
	void SetStartFov(float value);
}

