using UnityEngine;
using System.Collections;

public class CutLookFrame : LookFrame
{
	private Vector3 localOffsetPosition;
	private Vector3 eulerAngles;
	private bool relative;
	
	public CutLookFrame(float startTime, float duration, GameEntity[] targetEntities, Vector3 eulerAngles, Transform cameraTransform, Vector3 localOffsetPosition, bool relative)
							 : base(startTime, duration, targetEntities, cameraTransform)
	{
		this.eulerAngles = eulerAngles;
		this.relative = relative;
		this.localOffsetPosition = localOffsetPosition;
	}
	
	public override Quaternion GetNextRotation(float elapsed)
	{
		if(eulerAngles!=Vector3.zero)
		{
			return Quaternion.Euler(eulerAngles);
		}
		
		if(localOffsetPosition!=Vector3.zero)
		{
			if(targetEntities!=null && relative)
			{
				return Quaternion.LookRotation(targetEntities[0].GetGameObject().transform.localToWorldMatrix.MultiplyPoint3x4(localOffsetPosition)-cameraTransform.position);
			}
			
			return Quaternion.LookRotation((GetTargetBounds().center+localOffsetPosition)-cameraTransform.position);
		}
	
		return Quaternion.LookRotation(GetTargetBounds().center-cameraTransform.position);
	}
}
