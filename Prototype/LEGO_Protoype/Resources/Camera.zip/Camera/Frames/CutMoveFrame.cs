using UnityEngine;
using System.Collections;

public class CutMoveFrame : Frame, IOrbit
{
	private Vector3 targetPosition;
	public CutMoveFrame(float startTime, float duration, bool relative, GameEntity[] relativeEntities, Vector3 targetPosition)
							 : base(startTime, duration, relativeEntities)
	{
		this.targetPosition = targetPosition;
	}
	
	public Vector3 GetNextPosition(float elapsed)
	{
		if(targetEntities==null)
		{
			return targetPosition;
		}
		else
		{
			return targetEntities[0].GetGameObject().transform.worldToLocalMatrix.MultiplyPoint3x4(targetPosition);
		}
	}
	
	public void SetStartAngleXZ(float value){}
	public void SetStartAngleXY(float value){}
	public void SetStartDistance(float value){}
}