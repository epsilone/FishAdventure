using UnityEngine;
using System.Collections;

public abstract class ZoomFrame : Frame, IZoom
{
	protected float targetFov;
	protected float fovlerpDuration;
	protected float startFov;
	
	public ZoomFrame(float startTime, float targetFov, float frameDuration, GameEntity[] targetEntities) : base(startTime, frameDuration, targetEntities) 
	{
		this.targetFov = targetFov;
	}
	
	public abstract float GetNextFov(float elapsed);
	
	public void SetStartFov(float startFov)
	{
		this.startFov = startFov;
	}
}

