using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class CameraManager
{
	private Camera mainCamera;
	private float startTime;
	private float duration;
	
	private List<Frame> totalFrames;
	private List<Frame> currentFrames;
	private List<Frame> deleteFrames;
	
	public CameraManager(Camera mainCamera)
	{
		totalFrames = new List<Frame>();
		currentFrames = new List<Frame>();
		deleteFrames = new List<Frame>();
		this.mainCamera = mainCamera;
	}
	
	public Camera GetCamera()
	{
		return mainCamera;
	}
	
	public void AddFrames(params Frame[] frames)
	{
		foreach(Frame f in frames)
		{
			totalFrames.Add(f);
		}		
	}
	
	public void Clear()
	{
		totalFrames.Clear();
		currentFrames.Clear();
		deleteFrames.Clear();
	}
	
	public void UpdateOrbit(float elapsed)
	{
		for(int i=0; i<currentFrames.Count; ++i)
		{
			Frame currentFrame = currentFrames[i];
			
			float frameEndTime = currentFrame.GetStartTime()+currentFrame.GetDuration();
			
			if(elapsed>=currentFrame.GetStartTime() && elapsed<frameEndTime)
			{
				float localFrameTime = Mathf.Clamp(elapsed-currentFrame.GetStartTime(), 0, currentFrame.GetDuration());
				
				if(currentFrame is IOrbit)
				{
					mainCamera.transform.position = (currentFrame as IOrbit).GetNextPosition(localFrameTime);
				}
			}
		}
		
	}
	
	public void Update(float elapsed)
	{
		for(int i=0; i<currentFrames.Count; ++i)
		{
			Frame currentFrame = currentFrames[i];
			
			float frameEndTime = currentFrame.GetStartTime()+currentFrame.GetDuration();
			
			if(elapsed>=currentFrame.GetStartTime() && elapsed<=frameEndTime)
			{
				float localFrameTime = Mathf.Clamp(elapsed-currentFrame.GetStartTime(), 0, currentFrame.GetDuration());

				if(currentFrame is ILook)
				{
					mainCamera.transform.rotation = (currentFrame as ILook).GetNextRotation(localFrameTime);
				}
				if(currentFrame is IZoom)
				{
					mainCamera.fov = (currentFrame as IZoom).GetNextFov(localFrameTime);
				}
			}
		}
		
		foreach(Frame frame in totalFrames)
		{
			float frameEndTime = frame.GetStartTime() + frame.GetDuration();
			if(elapsed>frameEndTime)
			{
				deleteFrames.Add(frame);
			}
			
			else if(elapsed>=frame.GetStartTime() && elapsed<frame.GetStartTime()+frameEndTime && !currentFrames.Contains(frame))
			{
				currentFrames.Add(frame);
				//NewFrame(frame);
			}
		}
		
		foreach(Frame f in deleteFrames)
		{
			if(currentFrames.Contains(f))
			{
				totalFrames.Remove(f);
				currentFrames.Remove(f);
			}
		}
	}
	
	private void NewFrame(Frame newFrame)
	{
		if(newFrame is IOrbit)
		{
			IOrbit orbitFrame = (IOrbit) newFrame;
			
			Vector2 xz = new Vector2(mainCamera.transform.position.x, mainCamera.transform.position.z).normalized;
			Vector2 xy = new Vector2(mainCamera.transform.position.x, mainCamera.transform.position.y).normalized;
			
			orbitFrame.SetStartAngleXZ(Mathf.Asin(xz.x)*Mathf.Rad2Deg);
			orbitFrame.SetStartAngleXY(Mathf.Acos(xy.y)*Mathf.Rad2Deg);
			//orbitFrame.SetStartDistance(Vector3.Distance(mainCamera.transform.position, newFrame.GetTargetBoundsCenter()));
		}
		
		else if(newFrame is IZoom)
		{
			IZoom zoomFrame = (IZoom) newFrame;
			zoomFrame.SetStartFov(mainCamera.fov);
		}
		
		else if(newFrame is ILook)
		{
			ILook lookFrame = (ILook) newFrame;
			lookFrame.SetStartLookPosition(mainCamera.transform.position);
		}
	}	
}

